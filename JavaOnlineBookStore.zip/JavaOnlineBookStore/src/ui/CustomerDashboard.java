package ui;

import dao.BookDAO;
import models.Book;
import models.User;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class CustomerDashboard extends JFrame {
    
    private User currentUser;
    private BookDAO bookDAO;
    private JTable bookTable;
    private DefaultTableModel tableModel;
    private JTextField searchField;
    private List<Book> cart;
    private JLabel cartLabel;
    
    public CustomerDashboard(User user) {
        this.currentUser = user;
        this.bookDAO = new BookDAO();
        this.cart = new ArrayList<>();
        initComponents();
        loadBooks();
    }
    
    private void initComponents() {
        setTitle("Customer Dashboard - " + currentUser.getFullName());
        setSize(1000, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // Main Panel
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(Color.WHITE);
        
        // Top Panel
        JPanel topPanel = new JPanel();
        topPanel.setBackground(new Color(41, 128, 185));
        topPanel.setPreferredSize(new Dimension(1000, 70));
        topPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 20, 15));
        
        JLabel welcomeLabel = new JLabel("Welcome, " + currentUser.getFullName());
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 18));
        welcomeLabel.setForeground(Color.WHITE);
        topPanel.add(welcomeLabel);
        
        cartLabel = new JLabel("🛒 Cart: 0 items");
        cartLabel.setFont(new Font("Arial", Font.BOLD, 14));
        cartLabel.setForeground(Color.WHITE);
        topPanel.add(cartLabel);
        
        JButton cartBtn = new JButton("View Cart");
        cartBtn.setBackground(new Color(46, 204, 113));
        cartBtn.setForeground(Color.WHITE);
        cartBtn.setFont(new Font("Arial", Font.BOLD, 12));
        cartBtn.setFocusPainted(false);
        cartBtn.addActionListener(e -> viewCart());
        topPanel.add(cartBtn);
        
        JButton logoutBtn = new JButton("Logout");
        logoutBtn.setBackground(new Color(231, 76, 60));
        logoutBtn.setForeground(Color.WHITE);
        logoutBtn.setFont(new Font("Arial", Font.BOLD, 12));
        logoutBtn.setFocusPainted(false);
        logoutBtn.addActionListener(e -> {
            new LoginFrame().setVisible(true);
            this.dispose();
        });
        topPanel.add(logoutBtn);
        
        mainPanel.add(topPanel, BorderLayout.NORTH);
        
        // Center Panel
        JPanel centerPanel = new JPanel(new BorderLayout(10, 10));
        centerPanel.setBackground(Color.WHITE);
        centerPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Search Panel
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        searchPanel.setBackground(Color.WHITE);
        
        JLabel searchLabel = new JLabel("Search Books:");
        searchLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        searchPanel.add(searchLabel);
        
        searchField = new JTextField(25);
        searchField.setFont(new Font("Arial", Font.PLAIN, 14));
        searchPanel.add(searchField);
        
        JButton searchBtn = new JButton("Search");
        searchBtn.setBackground(new Color(52, 152, 219));
        searchBtn.setForeground(Color.WHITE);
        searchBtn.setFocusPainted(false);
        searchBtn.addActionListener(e -> searchBooks());
        searchPanel.add(searchBtn);
        
        JButton refreshBtn = new JButton("Show All");
        refreshBtn.setBackground(new Color(46, 204, 113));
        refreshBtn.setForeground(Color.WHITE);
        refreshBtn.setFocusPainted(false);
        refreshBtn.addActionListener(e -> loadBooks());
        searchPanel.add(refreshBtn);
        
        centerPanel.add(searchPanel, BorderLayout.NORTH);
        
        // Table
        String[] columns = {"ID", "Title", "Author", "Category", "Price", "Stock", "Publisher"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        bookTable = new JTable(tableModel);
        bookTable.setFont(new Font("Arial", Font.PLAIN, 12));
        bookTable.setRowHeight(30);
        bookTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        bookTable.getTableHeader().setBackground(new Color(52, 73, 94));
        bookTable.getTableHeader().setForeground(Color.WHITE);
        bookTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        JScrollPane scrollPane = new JScrollPane(bookTable);
        centerPanel.add(scrollPane, BorderLayout.CENTER);
        
        mainPanel.add(centerPanel, BorderLayout.CENTER);
        
        // Bottom Panel - NOW WITH REVIEW BUTTON
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        bottomPanel.setBackground(new Color(236, 240, 241));
        bottomPanel.setPreferredSize(new Dimension(1000, 60));
        
        JButton addToCartBtn = createButton("Add to Cart", new Color(46, 204, 113));
        addToCartBtn.addActionListener(e -> addToCart());
        bottomPanel.add(addToCartBtn);
        
        JButton viewDetailsBtn = createButton("View Details", new Color(52, 152, 219));
        viewDetailsBtn.addActionListener(e -> viewBookDetails());
        bottomPanel.add(viewDetailsBtn);
        
        // NEW: Write Review Button
        JButton reviewBtn = createButton("Write Review", new Color(155, 89, 182));
        reviewBtn.addActionListener(e -> openReviewDialog());
        bottomPanel.add(reviewBtn);
        
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);
        
        add(mainPanel);
    }
    
    private JButton createButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 13));
        button.setPreferredSize(new Dimension(150, 35));
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }
    
    private void loadBooks() {
        tableModel.setRowCount(0);
        List<Book> books = bookDAO.getAllBooks();
        
        for (Book book : books) {
            if (book.getStockQuantity() > 0) {
                Object[] row = {
                    book.getBookId(),
                    book.getTitle(),
                    book.getAuthor(),
                    book.getCategory(),
                    "$" + book.getPrice(),
                    book.getStockQuantity(),
                    book.getPublisher()
                };
                tableModel.addRow(row);
            }
        }
    }
    
    private void searchBooks() {
        String keyword = searchField.getText().trim();
        if (keyword.isEmpty()) {
            loadBooks();
            return;
        }
        
        tableModel.setRowCount(0);
        List<Book> books = bookDAO.searchBooks(keyword);
        
        for (Book book : books) {
            if (book.getStockQuantity() > 0) {
                Object[] row = {
                    book.getBookId(),
                    book.getTitle(),
                    book.getAuthor(),
                    book.getCategory(),
                    "$" + book.getPrice(),
                    book.getStockQuantity(),
                    book.getPublisher()
                };
                tableModel.addRow(row);
            }
        }
    }
    
    private void addToCart() {
        int selectedRow = bookTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a book to add to cart!", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int bookId = (int) tableModel.getValueAt(selectedRow, 0);
        List<Book> allBooks = bookDAO.getAllBooks();
        Book selectedBook = allBooks.stream().filter(b -> b.getBookId() == bookId).findFirst().orElse(null);
        
        if (selectedBook != null) {
            // Check if book already in cart
            boolean alreadyInCart = cart.stream().anyMatch(b -> b.getBookId() == bookId);
            
            if (alreadyInCart) {
                JOptionPane.showMessageDialog(this, "Book already in cart!", "Info", JOptionPane.INFORMATION_MESSAGE);
            } else {
                cart.add(selectedBook);
                updateCartLabel();
                JOptionPane.showMessageDialog(this, "Book added to cart successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }
    
    private void viewCart() {
        if (cart.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Your cart is empty!", "Cart", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        
        JDialog cartDialog = new JDialog(this, "Shopping Cart", true);
        cartDialog.setSize(700, 500);
        cartDialog.setLocationRelativeTo(this);
        cartDialog.setLayout(new BorderLayout());
        
        // Cart Table
        String[] columns = {"Title", "Author", "Price", "Action"};
        DefaultTableModel cartTableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        JTable cartTable = new JTable(cartTableModel);
        cartTable.setRowHeight(30);
        cartTable.setFont(new Font("Arial", Font.PLAIN, 12));
        
        double total = 0;
        for (Book book : cart) {
            Object[] row = {
                book.getTitle(),
                book.getAuthor(),
                "$" + book.getPrice(),
                "Remove"
            };
            cartTableModel.addRow(row);
            total += book.getPrice();
        }
        
        JScrollPane scrollPane = new JScrollPane(cartTable);
        cartDialog.add(scrollPane, BorderLayout.CENTER);
        
        // Bottom Panel
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        
        JLabel totalLabel = new JLabel("Total: $" + String.format("%.2f", total));
        totalLabel.setFont(new Font("Arial", Font.BOLD, 16));
        bottomPanel.add(totalLabel);
        
        JButton removeBtn = new JButton("Remove Selected");
        removeBtn.setBackground(new Color(231, 76, 60));
        removeBtn.setForeground(Color.WHITE);
        removeBtn.addActionListener(e -> {
            int row = cartTable.getSelectedRow();
            if (row != -1) {
                cart.remove(row);
                cartTableModel.removeRow(row);
                updateCartLabel();
                
                // Update total
                double newTotal = 0;
                for (Book book : cart) {
                    newTotal += book.getPrice();
                }
                totalLabel.setText("Total: $" + String.format("%.2f", newTotal));
            }
        });
        bottomPanel.add(removeBtn);
        
        // UPDATED: Checkout button now opens Payment Dialog
        final double finalTotal = total;
        JButton checkoutBtn = new JButton("Checkout");
        checkoutBtn.setBackground(new Color(46, 204, 113));
        checkoutBtn.setForeground(Color.WHITE);
        checkoutBtn.addActionListener(e -> {
            // Open payment dialog
            PaymentDialog paymentDialog = new PaymentDialog(this, currentUser, new ArrayList<>(cart), finalTotal);
            paymentDialog.setVisible(true);
            
            // If payment successful, clear cart and update
            if (paymentDialog.isPaymentSuccessful()) {
                // Update stock for all books in cart
                for (Book book : cart) {
                    bookDAO.updateStock(book.getBookId(), book.getStockQuantity() - 1);
                }
                
                cart.clear();
                updateCartLabel();
                loadBooks();
                cartDialog.dispose();
            }
        });
        bottomPanel.add(checkoutBtn);
        
        JButton closeBtn = new JButton("Close");
        closeBtn.addActionListener(e -> cartDialog.dispose());
        bottomPanel.add(closeBtn);
        
        cartDialog.add(bottomPanel, BorderLayout.SOUTH);
        cartDialog.setVisible(true);
    }
    
    private void viewBookDetails() {
        int selectedRow = bookTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a book!", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int bookId = (int) tableModel.getValueAt(selectedRow, 0);
        List<Book> books = bookDAO.getAllBooks();
        Book book = books.stream().filter(b -> b.getBookId() == bookId).findFirst().orElse(null);
        
        if (book != null) {
            String details = "═══════════════════════════════\n" +
                            "        BOOK DETAILS\n" +
                            "═══════════════════════════════\n\n" +
                            "Title: " + book.getTitle() + "\n" +
                            "Author: " + book.getAuthor() + "\n" +
                            "ISBN: " + book.getIsbn() + "\n" +
                            "Category: " + book.getCategory() + "\n" +
                            "Price: $" + book.getPrice() + "\n" +
                            "Stock Available: " + book.getStockQuantity() + "\n" +
                            "Publisher: " + book.getPublisher() + "\n" +
                            "Year: " + book.getPublicationYear() + "\n" +
                            "Description: " + (book.getDescription() != null ? book.getDescription() : "N/A");
            
            JOptionPane.showMessageDialog(this, details, "Book Details", JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    private void updateCartLabel() {
        cartLabel.setText("🛒 Cart: " + cart.size() + " items");
    }
    
    // NEW METHOD: Open Review Dialog
    private void openReviewDialog() {
        int selectedRow = bookTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a book to review!", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int bookId = (int) tableModel.getValueAt(selectedRow, 0);
        List<Book> books = bookDAO.getAllBooks();
        Book selectedBook = books.stream().filter(b -> b.getBookId() == bookId).findFirst().orElse(null);
        
        if (selectedBook != null) {
            ReviewDialog reviewDialog = new ReviewDialog(this, currentUser, selectedBook);
            reviewDialog.setVisible(true);
        }
    }
}