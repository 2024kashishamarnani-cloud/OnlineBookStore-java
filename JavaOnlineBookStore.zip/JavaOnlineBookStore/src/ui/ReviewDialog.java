package ui;

import dao.ReviewDAO;
import models.Book;
import models.Review;
import models.User;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class ReviewDialog extends JDialog {
    
    private User currentUser;
    private Book selectedBook;
    private ReviewDAO reviewDAO;
    private JSlider ratingSlider;
    private JTextArea reviewTextArea;
    private JTextArea reviewsDisplayArea;
    
    public ReviewDialog(Frame parent, User user, Book book) {
        super(parent, "Book Reviews - " + book.getTitle(), true);
        this.currentUser = user;
        this.selectedBook = book;
        this.reviewDAO = new ReviewDAO();
        initComponents();
        loadExistingReviews();
    }
    
    private void initComponents() {
        setSize(600, 650);
        setLocationRelativeTo(getParent());
        setLayout(null);
        
        // Book Info Panel
        JPanel bookInfoPanel = new JPanel();
        bookInfoPanel.setBounds(20, 20, 560, 80);
        bookInfoPanel.setBorder(BorderFactory.createTitledBorder("Book Information"));
        bookInfoPanel.setLayout(null);
        
        JLabel titleLabel = new JLabel("Title: " + selectedBook.getTitle());
        titleLabel.setFont(new Font("Arial", Font.BOLD, 14));
        titleLabel.setBounds(15, 25, 530, 20);
        bookInfoPanel.add(titleLabel);
        
        JLabel authorLabel = new JLabel("Author: " + selectedBook.getAuthor());
        authorLabel.setFont(new Font("Arial", Font.PLAIN, 13));
        authorLabel.setBounds(15, 50, 300, 20);
        bookInfoPanel.add(authorLabel);
        
        add(bookInfoPanel);
        
        // Write Review Panel
        JPanel writeReviewPanel = new JPanel();
        writeReviewPanel.setBounds(20, 115, 560, 220);
        writeReviewPanel.setBorder(BorderFactory.createTitledBorder("Write Your Review"));
        writeReviewPanel.setLayout(null);
        
        // Rating slider
        JLabel ratingLabel = new JLabel("Your Rating:");
        ratingLabel.setFont(new Font("Arial", Font.BOLD, 13));
        ratingLabel.setBounds(15, 30, 100, 25);
        writeReviewPanel.add(ratingLabel);
        
        ratingSlider = new JSlider(1, 5, 5);
        ratingSlider.setBounds(120, 30, 300, 50);
        ratingSlider.setMajorTickSpacing(1);
        ratingSlider.setPaintTicks(true);
        ratingSlider.setPaintLabels(true);
        writeReviewPanel.add(ratingSlider);
        
        JLabel starLabel = new JLabel("★★★★★");
        starLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        starLabel.setForeground(new Color(255, 193, 7));
        starLabel.setBounds(430, 35, 100, 30);
        writeReviewPanel.add(starLabel);
        
        // Update stars based on slider
        ratingSlider.addChangeListener(e -> {
            int rating = ratingSlider.getValue();
            String stars = "★".repeat(rating) + "☆".repeat(5 - rating);
            starLabel.setText(stars);
        });
        
        JLabel reviewLabel = new JLabel("Your Review:");
        reviewLabel.setFont(new Font("Arial", Font.BOLD, 13));
        reviewLabel.setBounds(15, 90, 100, 25);
        writeReviewPanel.add(reviewLabel);
        
        reviewTextArea = new JTextArea();
        reviewTextArea.setFont(new Font("Arial", Font.PLAIN, 12));
        reviewTextArea.setLineWrap(true);
        reviewTextArea.setWrapStyleWord(true);
        JScrollPane reviewScroll = new JScrollPane(reviewTextArea);
        reviewScroll.setBounds(15, 120, 530, 60);
        writeReviewPanel.add(reviewScroll);
        
        JButton submitButton = new JButton("Submit Review");
        submitButton.setBounds(400, 185, 130, 30);
        submitButton.setBackground(new Color(46, 204, 113));
        submitButton.setForeground(Color.WHITE);
        submitButton.setFont(new Font("Arial", Font.BOLD, 12));
        submitButton.setFocusPainted(false);
        submitButton.addActionListener(e -> submitReview());
        writeReviewPanel.add(submitButton);
        
        add(writeReviewPanel);
        
        // Existing Reviews Panel
        JPanel reviewsPanel = new JPanel();
        reviewsPanel.setBounds(20, 350, 560, 240);
        reviewsPanel.setBorder(BorderFactory.createTitledBorder("Customer Reviews"));
        reviewsPanel.setLayout(new BorderLayout());
        
        reviewsDisplayArea = new JTextArea();
        reviewsDisplayArea.setFont(new Font("Arial", Font.PLAIN, 12));
        reviewsDisplayArea.setEditable(false);
        reviewsDisplayArea.setLineWrap(true);
        reviewsDisplayArea.setWrapStyleWord(true);
        JScrollPane reviewsScroll = new JScrollPane(reviewsDisplayArea);
        reviewsPanel.add(reviewsScroll, BorderLayout.CENTER);
        
        add(reviewsPanel);
        
        // Close button
        JButton closeButton = new JButton("Close");
        closeButton.setBounds(250, 600, 100, 30);
        closeButton.setBackground(new Color(149, 165, 166));
        closeButton.setForeground(Color.WHITE);
        closeButton.setFont(new Font("Arial", Font.BOLD, 12));
        closeButton.setFocusPainted(false);
        closeButton.addActionListener(e -> dispose());
        add(closeButton);
    }
    
    private void submitReview() {
        // Check if user already reviewed
        if (reviewDAO.hasUserReviewedBook(currentUser.getUserId(), selectedBook.getBookId())) {
            JOptionPane.showMessageDialog(this, 
                "You have already reviewed this book!", 
                "Already Reviewed", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int rating = ratingSlider.getValue();
        String reviewText = reviewTextArea.getText().trim();
        
        if (reviewText.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Please write a review!", 
                "Empty Review", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        // Create and save review
        Review review = new Review(selectedBook.getBookId(), currentUser.getUserId(), rating, reviewText);
        
        if (reviewDAO.addReview(review)) {
            JOptionPane.showMessageDialog(this, 
                "Thank you for your review!", 
                "Success", 
                JOptionPane.INFORMATION_MESSAGE);
            
            // Clear form
            reviewTextArea.setText("");
            ratingSlider.setValue(5);
            
            // Reload reviews
            loadExistingReviews();
        } else {
            JOptionPane.showMessageDialog(this, 
                "Failed to submit review!", 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void loadExistingReviews() {
        List<Review> reviews = reviewDAO.getReviewsByBookId(selectedBook.getBookId());
        
        if (reviews.isEmpty()) {
            reviewsDisplayArea.setText("No reviews yet. Be the first to review this book!");
            return;
        }
        
        StringBuilder sb = new StringBuilder();
        double avgRating = reviewDAO.getAverageRating(selectedBook.getBookId());
        
        sb.append("═══════════════════════════════════════════════════\n");
        sb.append(String.format("Average Rating: %.1f/5 ⭐ (%d reviews)\n", avgRating, reviews.size()));
        sb.append("═══════════════════════════════════════════════════\n\n");
        
        for (Review review : reviews) {
            sb.append("👤 ").append(review.getUsername()).append("\n");
            sb.append("Rating: ");
            sb.append("★".repeat(review.getRating()));
            sb.append("☆".repeat(5 - review.getRating()));
            sb.append(" (").append(review.getRating()).append("/5)\n");
            sb.append("Review: ").append(review.getReviewText()).append("\n");
            sb.append("Date: ").append(review.getReviewDate()).append("\n");
            sb.append("───────────────────────────────────────────────────\n\n");
        }
        
        reviewsDisplayArea.setText(sb.toString());
        reviewsDisplayArea.setCaretPosition(0);
    }
}
