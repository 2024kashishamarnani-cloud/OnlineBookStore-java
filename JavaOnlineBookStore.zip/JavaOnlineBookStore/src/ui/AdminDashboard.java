package ui;

import dao.BookDAO;
import models.Book;
import models.User;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class AdminDashboard extends JFrame {
    
    private User currentUser;
    private BookDAO bookDAO;
    private JTable bookTable;
    private DefaultTableModel tableModel;
    private JTextField searchField;
    
    public AdminDashboard(User user) {
        this.currentUser = user;
        this.bookDAO = new BookDAO();
        initComponents();
        loadBooks();
    }
    
    private void initComponents() {
        setTitle("Admin Dashboard - " + currentUser.getFullName());
        setSize(1000, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // Main Panel
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(Color.WHITE);
        
        // Top Panel
        JPanel topPanel = new JPanel();
        topPanel.setBackground(new Color(52, 73, 94));
        topPanel.setPreferredSize(new Dimension(1000, 70));
        topPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 20, 15));
        
        JLabel welcomeLabel = new JLabel("Welcome, " + currentUser.getFullName() + " (Admin)");
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 18));
        welcomeLabel.setForeground(Color.WHITE);
        topPanel.add(welcomeLabel);
        
        JButton logoutBtn = new JButton("Logout");
        logoutBtn.setBackground(new Color(231, 76, 60));
        logoutBtn.setForeground(Color.WHITE);
        logoutBtn.setFont(new Font("Arial", Font.BOLD, 12));
        logoutBtn.setFocusPainted(false);
        logoutBtn.addActionListener(e -> {
            new LoginFrame().setVisible(true);
            this.dispose();
        });
        topPanel.add(logoutBtn);
        
        mainPanel.add(topPanel, BorderLayout.NORTH);
        
        // Center Panel - Book Management
        JPanel centerPanel = new JPanel(new BorderLayout(10, 10));
        centerPanel.setBackground(Color.WHITE);
        centerPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Search Panel
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        searchPanel.setBackground(Color.WHITE);
        
        JLabel searchLabel = new JLabel("Search:");
        searchLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        searchPanel.add(searchLabel);
        
        searchField = new JTextField(25);
        searchField.setFont(new Font("Arial", Font.PLAIN, 14));
        searchPanel.add(searchField);
        
        JButton searchBtn = new JButton("Search");
        searchBtn.setBackground(new Color(52, 152, 219));
        searchBtn.setForeground(Color.WHITE);
        searchBtn.setFocusPainted(false);
        searchBtn.addActionListener(e -> searchBooks());
        searchPanel.add(searchBtn);
        
        JButton refreshBtn = new JButton("Refresh");
        refreshBtn.setBackground(new Color(46, 204, 113));
        refreshBtn.setForeground(Color.WHITE);
        refreshBtn.setFocusPainted(false);
        refreshBtn.addActionListener(e -> loadBooks());
        searchPanel.add(refreshBtn);
        
        centerPanel.add(searchPanel, BorderLayout.NORTH);
        
        // Table
        String[] columns = {"ID", "Title", "Author", "ISBN", "Category", "Price", "Stock", "Publisher", "Year"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        bookTable = new JTable(tableModel);
        bookTable.setFont(new Font("Arial", Font.PLAIN, 12));
        bookTable.setRowHeight(25);
        bookTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        bookTable.getTableHeader().setBackground(new Color(52, 73, 94));
        bookTable.getTableHeader().setForeground(Color.WHITE);
        bookTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        JScrollPane scrollPane = new JScrollPane(bookTable);
        centerPanel.add(scrollPane, BorderLayout.CENTER);
        
        mainPanel.add(centerPanel, BorderLayout.CENTER);
        
        // Bottom Panel - Action Buttons
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        bottomPanel.setBackground(new Color(236, 240, 241));
        bottomPanel.setPreferredSize(new Dimension(1000, 60));
        
        JButton addBtn = createButton("Add Book", new Color(46, 204, 113));
        addBtn.addActionListener(e -> openAddBookDialog());
        bottomPanel.add(addBtn);
        
        JButton editBtn = createButton("Edit Book", new Color(52, 152, 219));
        editBtn.addActionListener(e -> openEditBookDialog());
        bottomPanel.add(editBtn);
        
        JButton deleteBtn = createButton("Delete Book", new Color(231, 76, 60));
        deleteBtn.addActionListener(e -> deleteBook());
        bottomPanel.add(deleteBtn);
        
        JButton viewBtn = createButton("View Details", new Color(155, 89, 182));
        viewBtn.addActionListener(e -> viewBookDetails());
        bottomPanel.add(viewBtn);
        
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);
        
        add(mainPanel);
    }
    
    private JButton createButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 13));
        button.setPreferredSize(new Dimension(140, 35));
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }
    
    private void loadBooks() {
        tableModel.setRowCount(0);
        List<Book> books = bookDAO.getAllBooks();
        
        for (Book book : books) {
            Object[] row = {
                book.getBookId(),
                book.getTitle(),
                book.getAuthor(),
                book.getIsbn(),
                book.getCategory(),
                "$" + book.getPrice(),
                book.getStockQuantity(),
                book.getPublisher(),
                book.getPublicationYear()
            };
            tableModel.addRow(row);
        }
    }
    
    private void searchBooks() {
        String keyword = searchField.getText().trim();
        if (keyword.isEmpty()) {
            loadBooks();
            return;
        }
        
        tableModel.setRowCount(0);
        List<Book> books = bookDAO.searchBooks(keyword);
        
        for (Book book : books) {
            Object[] row = {
                book.getBookId(),
                book.getTitle(),
                book.getAuthor(),
                book.getIsbn(),
                book.getCategory(),
                "$" + book.getPrice(),
                book.getStockQuantity(),
                book.getPublisher(),
                book.getPublicationYear()
            };
            tableModel.addRow(row);
        }
    }
    
    private void openAddBookDialog() {
        JDialog dialog = new JDialog(this, "Add New Book", true);
        dialog.setSize(450, 550);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(null);
        
        // Form fields
        addFormField(dialog, "Title:", 30, new JTextField());
        addFormField(dialog, "Author:", 80, new JTextField());
        addFormField(dialog, "ISBN:", 130, new JTextField());
        addFormField(dialog, "Category:", 180, new JTextField());
        addFormField(dialog, "Price:", 230, new JTextField());
        addFormField(dialog, "Stock Qty:", 280, new JTextField());
        addFormField(dialog, "Publisher:", 330, new JTextField());
        addFormField(dialog, "Year:", 380, new JTextField());
        
        JButton saveBtn = new JButton("Save Book");
        saveBtn.setBounds(160, 450, 130, 35);
        saveBtn.setBackground(new Color(46, 204, 113));
        saveBtn.setForeground(Color.WHITE);
        saveBtn.setFont(new Font("Arial", Font.BOLD, 13));
        
        saveBtn.addActionListener(e -> {
            try {
                Book book = new Book();
                book.setTitle(((JTextField)dialog.getContentPane().getComponent(1)).getText());
                book.setAuthor(((JTextField)dialog.getContentPane().getComponent(3)).getText());
                book.setIsbn(((JTextField)dialog.getContentPane().getComponent(5)).getText());
                book.setCategory(((JTextField)dialog.getContentPane().getComponent(7)).getText());
                book.setPrice(Double.parseDouble(((JTextField)dialog.getContentPane().getComponent(9)).getText()));
                book.setStockQuantity(Integer.parseInt(((JTextField)dialog.getContentPane().getComponent(11)).getText()));
                book.setPublisher(((JTextField)dialog.getContentPane().getComponent(13)).getText());
                book.setPublicationYear(Integer.parseInt(((JTextField)dialog.getContentPane().getComponent(15)).getText()));
                book.setDescription("");
                
                if (bookDAO.addBook(book)) {
                    JOptionPane.showMessageDialog(dialog, "Book added successfully!");
                    loadBooks();
                    dialog.dispose();
                } else {
                    JOptionPane.showMessageDialog(dialog, "Failed to add book!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, "Invalid input! Please check all fields.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        
        dialog.add(saveBtn);
        dialog.setVisible(true);
    }
    
    private void openEditBookDialog() {
        int selectedRow = bookTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a book to edit!", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int bookId = (int) tableModel.getValueAt(selectedRow, 0);
        List<Book> books = bookDAO.getAllBooks();
        Book selectedBook = books.stream().filter(b -> b.getBookId() == bookId).findFirst().orElse(null);
        
        if (selectedBook == null) return;
        
        JDialog dialog = new JDialog(this, "Edit Book", true);
        dialog.setSize(450, 550);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(null);
        
        JTextField[] fields = new JTextField[8];
        fields[0] = addFormFieldWithValue(dialog, "Title:", 30, selectedBook.getTitle());
        fields[1] = addFormFieldWithValue(dialog, "Author:", 80, selectedBook.getAuthor());
        fields[2] = addFormFieldWithValue(dialog, "ISBN:", 130, selectedBook.getIsbn());
        fields[3] = addFormFieldWithValue(dialog, "Category:", 180, selectedBook.getCategory());
        fields[4] = addFormFieldWithValue(dialog, "Price:", 230, String.valueOf(selectedBook.getPrice()));
        fields[5] = addFormFieldWithValue(dialog, "Stock Qty:", 280, String.valueOf(selectedBook.getStockQuantity()));
        fields[6] = addFormFieldWithValue(dialog, "Publisher:", 330, selectedBook.getPublisher());
        fields[7] = addFormFieldWithValue(dialog, "Year:", 380, String.valueOf(selectedBook.getPublicationYear()));
        
        JButton updateBtn = new JButton("Update Book");
        updateBtn.setBounds(160, 450, 130, 35);
        updateBtn.setBackground(new Color(52, 152, 219));
        updateBtn.setForeground(Color.WHITE);
        updateBtn.setFont(new Font("Arial", Font.BOLD, 13));
        
        updateBtn.addActionListener(e -> {
            try {
                selectedBook.setTitle(fields[0].getText());
                selectedBook.setAuthor(fields[1].getText());
                selectedBook.setIsbn(fields[2].getText());
                selectedBook.setCategory(fields[3].getText());
                selectedBook.setPrice(Double.parseDouble(fields[4].getText()));
                selectedBook.setStockQuantity(Integer.parseInt(fields[5].getText()));
                selectedBook.setPublisher(fields[6].getText());
                selectedBook.setPublicationYear(Integer.parseInt(fields[7].getText()));
                
                if (bookDAO.updateBook(selectedBook)) {
                    JOptionPane.showMessageDialog(dialog, "Book updated successfully!");
                    loadBooks();
                    dialog.dispose();
                } else {
                    JOptionPane.showMessageDialog(dialog, "Failed to update book!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, "Invalid input!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        
        dialog.add(updateBtn);
        dialog.setVisible(true);
    }
    
    private void deleteBook() {
        int selectedRow = bookTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a book to delete!", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this book?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            int bookId = (int) tableModel.getValueAt(selectedRow, 0);
            if (bookDAO.deleteBook(bookId)) {
                JOptionPane.showMessageDialog(this, "Book deleted successfully!");
                loadBooks();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to delete book!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private void viewBookDetails() {
        int selectedRow = bookTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a book!", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        String details = "Book ID: " + tableModel.getValueAt(selectedRow, 0) + "\n" +
                        "Title: " + tableModel.getValueAt(selectedRow, 1) + "\n" +
                        "Author: " + tableModel.getValueAt(selectedRow, 2) + "\n" +
                        "ISBN: " + tableModel.getValueAt(selectedRow, 3) + "\n" +
                        "Category: " + tableModel.getValueAt(selectedRow, 4) + "\n" +
                        "Price: " + tableModel.getValueAt(selectedRow, 5) + "\n" +
                        "Stock: " + tableModel.getValueAt(selectedRow, 6) + "\n" +
                        "Publisher: " + tableModel.getValueAt(selectedRow, 7) + "\n" +
                        "Year: " + tableModel.getValueAt(selectedRow, 8);
        
        JOptionPane.showMessageDialog(this, details, "Book Details", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void addFormField(JDialog dialog, String label, int y, JTextField field) {
        JLabel lbl = new JLabel(label);
        lbl.setBounds(50, y, 100, 25);
        lbl.setFont(new Font("Arial", Font.PLAIN, 13));
        dialog.add(lbl);
        
        field.setBounds(160, y, 240, 30);
        field.setFont(new Font("Arial", Font.PLAIN, 13));
        dialog.add(field);
    }
    
    private JTextField addFormFieldWithValue(JDialog dialog, String label, int y, String value) {
        JLabel lbl = new JLabel(label);
        lbl.setBounds(50, y, 100, 25);
        lbl.setFont(new Font("Arial", Font.PLAIN, 13));
        dialog.add(lbl);
        
        JTextField field = new JTextField(value);
        field.setBounds(160, y, 240, 30);
        field.setFont(new Font("Arial", Font.PLAIN, 13));
        dialog.add(field);
        
        return field;
    }
}
