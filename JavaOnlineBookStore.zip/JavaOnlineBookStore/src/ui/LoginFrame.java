package ui;

import dao.UserDAO;
import models.User;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LoginFrame extends JFrame {
    
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton, registerButton;
    private UserDAO userDAO;
    
    public LoginFrame() {
        userDAO = new UserDAO();
        initComponents();
    }
    
    private void initComponents() {
        setTitle("Bookstore Management System - Login");
        setSize(450, 350);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        
        // Main panel with gradient background
        JPanel mainPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(0, 0, new Color(52, 152, 219), 0, getHeight(), new Color(41, 128, 185));
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        mainPanel.setLayout(null);
        
        // Title Label
        JLabel titleLabel = new JLabel("BOOKSTORE LOGIN");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBounds(90, 30, 300, 40);
        mainPanel.add(titleLabel);
        
        // Login Panel
        JPanel loginPanel = new JPanel();
        loginPanel.setBackground(Color.WHITE);
        loginPanel.setBounds(50, 90, 350, 180);
        loginPanel.setLayout(null);
        loginPanel.setBorder(BorderFactory.createLineBorder(new Color(189, 195, 199), 2));
        
        // Username
        JLabel userLabel = new JLabel("Username:");
        userLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        userLabel.setBounds(30, 30, 100, 25);
        loginPanel.add(userLabel);
        
        usernameField = new JTextField();
        usernameField.setBounds(130, 30, 180, 30);
        usernameField.setFont(new Font("Arial", Font.PLAIN, 14));
        loginPanel.add(usernameField);
        
        // Password
        JLabel passLabel = new JLabel("Password:");
        passLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        passLabel.setBounds(30, 75, 100, 25);
        loginPanel.add(passLabel);
        
        passwordField = new JPasswordField();
        passwordField.setBounds(130, 75, 180, 30);
        passwordField.setFont(new Font("Arial", Font.PLAIN, 14));
        loginPanel.add(passwordField);
        
        // Login Button
        loginButton = new JButton("LOGIN");
        loginButton.setBounds(50, 125, 120, 35);
        loginButton.setBackground(new Color(46, 204, 113));
        loginButton.setForeground(Color.WHITE);
        loginButton.setFont(new Font("Arial", Font.BOLD, 14));
        loginButton.setFocusPainted(false);
        loginButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        loginPanel.add(loginButton);
        
        // Register Button
        registerButton = new JButton("REGISTER");
        registerButton.setBounds(180, 125, 120, 35);
        registerButton.setBackground(new Color(52, 152, 219));
        registerButton.setForeground(Color.WHITE);
        registerButton.setFont(new Font("Arial", Font.BOLD, 14));
        registerButton.setFocusPainted(false);
        registerButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        loginPanel.add(registerButton);
        
        mainPanel.add(loginPanel);
        
        // Action Listeners
        loginButton.addActionListener(e -> handleLogin());
        registerButton.addActionListener(e -> openRegisterDialog());
        
        // Enter key for login
        passwordField.addActionListener(e -> handleLogin());
        
        add(mainPanel);
    }
    
    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());
        
        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter username and password!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        User user = userDAO.loginUser(username, password);
        
        if (user != null) {
            JOptionPane.showMessageDialog(this, "Login Successful!\nWelcome " + user.getFullName(), "Success", JOptionPane.INFORMATION_MESSAGE);
            
            // Open appropriate dashboard based on role
            if ("admin".equals(user.getRole())) {
                new AdminDashboard(user).setVisible(true);
            } else {
                new CustomerDashboard(user).setVisible(true);
            }
            
            this.dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Invalid username or password!", "Login Failed", JOptionPane.ERROR_MESSAGE);
            passwordField.setText("");
        }
    }
    
    private void openRegisterDialog() {
        JDialog registerDialog = new JDialog(this, "Register New User", true);
        registerDialog.setSize(400, 400);
        registerDialog.setLocationRelativeTo(this);
        registerDialog.setLayout(null);
        
        JLabel titleLbl = new JLabel("Create New Account");
        titleLbl.setFont(new Font("Arial", Font.BOLD, 18));
        titleLbl.setBounds(110, 20, 200, 30);
        registerDialog.add(titleLbl);
        
        // Form fields
        JLabel userLbl = new JLabel("Username:");
        userLbl.setBounds(50, 70, 100, 25);
        registerDialog.add(userLbl);
        
        JTextField userField = new JTextField();
        userField.setBounds(160, 70, 180, 25);
        registerDialog.add(userField);
        
        JLabel passLbl = new JLabel("Password:");
        passLbl.setBounds(50, 110, 100, 25);
        registerDialog.add(passLbl);
        
        JPasswordField passField = new JPasswordField();
        passField.setBounds(160, 110, 180, 25);
        registerDialog.add(passField);
        
        JLabel nameLbl = new JLabel("Full Name:");
        nameLbl.setBounds(50, 150, 100, 25);
        registerDialog.add(nameLbl);
        
        JTextField nameField = new JTextField();
        nameField.setBounds(160, 150, 180, 25);
        registerDialog.add(nameField);
        
        JLabel emailLbl = new JLabel("Email:");
        emailLbl.setBounds(50, 190, 100, 25);
        registerDialog.add(emailLbl);
        
        JTextField emailField = new JTextField();
        emailField.setBounds(160, 190, 180, 25);
        registerDialog.add(emailField);
        
        JLabel roleLbl = new JLabel("Role:");
        roleLbl.setBounds(50, 230, 100, 25);
        registerDialog.add(roleLbl);
        
        String[] roles = {"customer", "admin"};
        JComboBox<String> roleBox = new JComboBox<>(roles);
        roleBox.setBounds(160, 230, 180, 25);
        registerDialog.add(roleBox);
        
        JButton submitBtn = new JButton("Register");
        submitBtn.setBounds(140, 280, 120, 35);
        submitBtn.setBackground(new Color(46, 204, 113));
        submitBtn.setForeground(Color.WHITE);
        submitBtn.setFont(new Font("Arial", Font.BOLD, 14));
        registerDialog.add(submitBtn);
        
        submitBtn.addActionListener(e -> {
            String username = userField.getText().trim();
            String password = new String(passField.getPassword());
            String fullName = nameField.getText().trim();
            String email = emailField.getText().trim();
            String role = (String) roleBox.getSelectedItem();
            
            if (username.isEmpty() || password.isEmpty() || fullName.isEmpty() || email.isEmpty()) {
                JOptionPane.showMessageDialog(registerDialog, "All fields are required!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            if (userDAO.usernameExists(username)) {
                JOptionPane.showMessageDialog(registerDialog, "Username already exists!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            User newUser = new User();
            newUser.setUsername(username);
            newUser.setPassword(password);
            newUser.setFullName(fullName);
            newUser.setEmail(email);
            newUser.setRole(role);
            
            if (userDAO.registerUser(newUser)) {
                JOptionPane.showMessageDialog(registerDialog, "Registration successful! You can now login.", "Success", JOptionPane.INFORMATION_MESSAGE);
                registerDialog.dispose();
            } else {
                JOptionPane.showMessageDialog(registerDialog, "Registration failed! Try again.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        
        registerDialog.setVisible(true);
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new LoginFrame().setVisible(true);
        });
    }
}
