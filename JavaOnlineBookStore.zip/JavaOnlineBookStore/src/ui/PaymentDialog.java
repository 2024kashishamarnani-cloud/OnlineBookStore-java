package ui;

import dao.OrderDAO;
import dao.PaymentDAO;
import models.Book;
import models.Order;
import models.Payment;
import models.User;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class PaymentDialog extends JDialog {
    
    private User currentUser;
    private List<Book> cartItems;
    private double totalAmount;
    private JTextField cardNumberField;
    private JTextField cardHolderField;
    private JTextField cvvField;
    private JTextField expiryField;
    private JTextArea addressArea;
    private JComboBox<String> paymentMethodBox;
    private boolean paymentSuccessful = false;
    
    public PaymentDialog(Frame parent, User user, List<Book> cart, double total) {
        super(parent, "Payment & Checkout", true);
        this.currentUser = user;
        this.cartItems = cart;
        this.totalAmount = total;
        initComponents();
    }
    
    private void initComponents() {
        setSize(500, 650);
        setLocationRelativeTo(getParent());
        setLayout(null);
        setResizable(false);
        
        // Title
        JLabel titleLabel = new JLabel("Complete Your Purchase");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setBounds(130, 20, 250, 30);
        add(titleLabel);
        
        // Order Summary
        JPanel summaryPanel = new JPanel();
        summaryPanel.setBounds(30, 60, 440, 80);
        summaryPanel.setBorder(BorderFactory.createTitledBorder("Order Summary"));
        summaryPanel.setLayout(null);
        
        JLabel itemsLabel = new JLabel("Items: " + cartItems.size());
        itemsLabel.setBounds(20, 25, 200, 20);
        summaryPanel.add(itemsLabel);
        
        JLabel totalLabel = new JLabel("Total Amount: $" + String.format("%.2f", totalAmount));
        totalLabel.setFont(new Font("Arial", Font.BOLD, 16));
        totalLabel.setForeground(new Color(46, 204, 113));
        totalLabel.setBounds(20, 50, 300, 25);
        summaryPanel.add(totalLabel);
        
        add(summaryPanel);
        
        // Payment Method
        JLabel methodLabel = new JLabel("Payment Method:");
        methodLabel.setFont(new Font("Arial", Font.BOLD, 13));
        methodLabel.setBounds(30, 155, 150, 25);
        add(methodLabel);
        
        String[] methods = {"Credit Card", "Debit Card", "PayPal", "Cash on Delivery"};
        paymentMethodBox = new JComboBox<>(methods);
        paymentMethodBox.setBounds(180, 155, 290, 30);
        paymentMethodBox.setFont(new Font("Arial", Font.PLAIN, 13));
        add(paymentMethodBox);
        
        // Card Details Panel
        JPanel cardPanel = new JPanel();
        cardPanel.setBounds(30, 200, 440, 200);
        cardPanel.setBorder(BorderFactory.createTitledBorder("Card Details"));
        cardPanel.setLayout(null);
        
        JLabel cardNumLabel = new JLabel("Card Number:");
        cardNumLabel.setBounds(20, 30, 120, 25);
        cardPanel.add(cardNumLabel);
        
        cardNumberField = new JTextField();
        cardNumberField.setBounds(140, 30, 270, 30);
        cardNumberField.setFont(new Font("Arial", Font.PLAIN, 13));
        cardPanel.add(cardNumberField);
        
        JLabel holderLabel = new JLabel("Card Holder:");
        holderLabel.setBounds(20, 75, 120, 25);
        cardPanel.add(holderLabel);
        
        cardHolderField = new JTextField();
        cardHolderField.setBounds(140, 75, 270, 30);
        cardHolderField.setFont(new Font("Arial", Font.PLAIN, 13));
        cardPanel.add(cardHolderField);
        
        JLabel cvvLabel = new JLabel("CVV:");
        cvvLabel.setBounds(20, 120, 120, 25);
        cardPanel.add(cvvLabel);
        
        cvvField = new JTextField();
        cvvField.setBounds(140, 120, 100, 30);
        cvvField.setFont(new Font("Arial", Font.PLAIN, 13));
        cardPanel.add(cvvField);
        
        JLabel expiryLabel = new JLabel("Expiry (MM/YY):");
        expiryLabel.setBounds(20, 165, 120, 25);
        cardPanel.add(expiryLabel);
        
        expiryField = new JTextField();
        expiryField.setBounds(140, 165, 100, 30);
        expiryField.setFont(new Font("Arial", Font.PLAIN, 13));
        cardPanel.add(expiryField);
        
        add(cardPanel);
        
        // Shipping Address
        JLabel addressLabel = new JLabel("Shipping Address:");
        addressLabel.setFont(new Font("Arial", Font.BOLD, 13));
        addressLabel.setBounds(30, 415, 150, 25);
        add(addressLabel);
        
        addressArea = new JTextArea();
        addressArea.setFont(new Font("Arial", Font.PLAIN, 12));
        addressArea.setLineWrap(true);
        addressArea.setWrapStyleWord(true);
        addressArea.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        JScrollPane addressScroll = new JScrollPane(addressArea);
        addressScroll.setBounds(30, 445, 440, 80);
        add(addressScroll);
        
        // Buttons
        JButton payButton = new JButton("Pay Now");
        payButton.setBounds(150, 550, 120, 40);
        payButton.setBackground(new Color(46, 204, 113));
        payButton.setForeground(Color.WHITE);
        payButton.setFont(new Font("Arial", Font.BOLD, 14));
        payButton.setFocusPainted(false);
        payButton.addActionListener(e -> processPayment());
        add(payButton);
        
        JButton cancelButton = new JButton("Cancel");
        cancelButton.setBounds(280, 550, 120, 40);
        cancelButton.setBackground(new Color(231, 76, 60));
        cancelButton.setForeground(Color.WHITE);
        cancelButton.setFont(new Font("Arial", Font.BOLD, 14));
        cancelButton.setFocusPainted(false);
        cancelButton.addActionListener(e -> dispose());
        add(cancelButton);
        
        // Payment method listener
        paymentMethodBox.addActionListener(e -> {
            String selected = (String) paymentMethodBox.getSelectedItem();
            boolean showCardDetails = !selected.equals("Cash on Delivery");
            
            cardNumberField.setEnabled(showCardDetails);
            cardHolderField.setEnabled(showCardDetails);
            cvvField.setEnabled(showCardDetails);
            expiryField.setEnabled(showCardDetails);
        });
    }
    
    private void processPayment() {
        // Validate inputs
        String paymentMethod = ((String) paymentMethodBox.getSelectedItem()).toLowerCase().replace(" ", "_");
        String address = addressArea.getText().trim();
        
        if (address.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter shipping address!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Validate card details if not COD
        if (!paymentMethod.equals("cash_on_delivery")) {
            String cardNumber = cardNumberField.getText().trim();
            String cardHolder = cardHolderField.getText().trim();
            String cvv = cvvField.getText().trim();
            String expiry = expiryField.getText().trim();
            
            if (cardNumber.isEmpty() || cardHolder.isEmpty() || cvv.isEmpty() || expiry.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill all card details!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Verify payment
            PaymentDAO paymentDAO = new PaymentDAO();
            if (!paymentDAO.verifyPayment(cardNumber, cvv, expiry)) {
                JOptionPane.showMessageDialog(this, "Invalid card details!", "Payment Failed", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }
        
        // Create order
        OrderDAO orderDAO = new OrderDAO();
        Order order = new Order(currentUser.getUserId(), totalAmount, address);
        order.setStatus("completed");
        
        int orderId = orderDAO.createOrder(order, cartItems);
        
        if (orderId > 0) {
            // Process payment
            if (!paymentMethod.equals("cash_on_delivery")) {
                Payment payment = new Payment(orderId, paymentMethod, totalAmount);
                payment.setCardNumber(cardNumberField.getText().trim());
                payment.setCardHolderName(cardHolderField.getText().trim());
                
                PaymentDAO paymentDAO = new PaymentDAO();
                paymentDAO.processPayment(payment);
                
                // Show success message
                String message = "Payment Successful!\n\n" +
                               "Order ID: " + orderId + "\n" +
                               "Transaction ID: " + payment.getTransactionId() + "\n" +
                               "Amount: $" + String.format("%.2f", totalAmount) + "\n\n" +
                               "Your order will be delivered soon!";
                
                JOptionPane.showMessageDialog(this, message, "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, 
                    "Order placed successfully!\nOrder ID: " + orderId + "\n\nPay cash on delivery.", 
                    "Success", JOptionPane.INFORMATION_MESSAGE);
            }
            
            paymentSuccessful = true;
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Failed to create order!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public boolean isPaymentSuccessful() {
        return paymentSuccessful;
    }
}
