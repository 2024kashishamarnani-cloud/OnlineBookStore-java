package dao;

import database.DatabaseConnection;
import models.Payment;
import java.sql.*;
import java.util.UUID;

public class PaymentDAO {
    
    // Process payment
    public boolean processPayment(Payment payment) {
        String query = "INSERT INTO payments (order_id, payment_method, card_number, card_holder_name, " +
                      "payment_status, transaction_id, amount) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            // Generate transaction ID
            String transactionId = "TXN" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
            
            pstmt.setInt(1, payment.getOrderId());
            pstmt.setString(2, payment.getPaymentMethod());
            pstmt.setString(3, payment.getCardNumber());
            pstmt.setString(4, payment.getCardHolderName());
            pstmt.setString(5, "completed"); // Simulating successful payment
            pstmt.setString(6, transactionId);
            pstmt.setDouble(7, payment.getAmount());
            
            int result = pstmt.executeUpdate();
            
            if (result > 0) {
                payment.setTransactionId(transactionId);
                payment.setPaymentStatus("completed");
                return true;
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    // Get payment by order ID
    public Payment getPaymentByOrderId(int orderId) {
        String query = "SELECT * FROM payments WHERE order_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setInt(1, orderId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                Payment payment = new Payment();
                payment.setPaymentId(rs.getInt("payment_id"));
                payment.setOrderId(rs.getInt("order_id"));
                payment.setPaymentMethod(rs.getString("payment_method"));
                payment.setCardNumber(rs.getString("card_number"));
                payment.setCardHolderName(rs.getString("card_holder_name"));
                payment.setPaymentStatus(rs.getString("payment_status"));
                payment.setTransactionId(rs.getString("transaction_id"));
                payment.setPaymentDate(rs.getTimestamp("payment_date"));
                payment.setAmount(rs.getDouble("amount"));
                return payment;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    // Validate card number (basic validation)
    public boolean validateCardNumber(String cardNumber) {
        // Remove spaces and dashes
        cardNumber = cardNumber.replaceAll("[-\\s]", "");
        
        // Check if it's 13-19 digits (standard card length)
        if (!cardNumber.matches("\\d{13,19}")) {
            return false;
        }
        
        // Luhn algorithm for card validation
        int sum = 0;
        boolean alternate = false;
        
        for (int i = cardNumber.length() - 1; i >= 0; i--) {
            int digit = Character.getNumericValue(cardNumber.charAt(i));
            
            if (alternate) {
                digit *= 2;
                if (digit > 9) {
                    digit -= 9;
                }
            }
            
            sum += digit;
            alternate = !alternate;
        }
        
        return (sum % 10 == 0);
    }
    
    // Simulate payment verification (in real app, this would call payment gateway)
    public boolean verifyPayment(String cardNumber, String cvv, String expiryDate) {
        // Basic validation
        if (cardNumber == null || cvv == null || expiryDate == null) {
            return false;
        }
        
        // Check CVV (3 or 4 digits)
        if (!cvv.matches("\\d{3,4}")) {
            return false;
        }
        
        // Check expiry format (MM/YY)
        if (!expiryDate.matches("\\d{2}/\\d{2}")) {
            return false;
        }
        
        // Validate card number
        return validateCardNumber(cardNumber);
    }
}